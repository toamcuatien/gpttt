# name-checker
Helps you check if words can be used as a minecraft user name 

This can helps you A LOT if you have a HUGE list

join my discord @ https://dsc.gg/rtx4090
